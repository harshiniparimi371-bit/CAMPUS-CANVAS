// CampusCanvas - SmartCampus backend
// Plain Node.js (http module only), so there is nothing to npm install.

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'campus@123';

const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const NOTICES_FILE = path.join(DATA_DIR, 'notices.json');
const INQUIRIES_FILE = path.join(DATA_DIR, 'inquiries.json');

const CATEGORIES = ['Academics', 'Examinations', 'Placements', 'Events', 'Sports'];
const PRIORITIES = ['urgent', 'high', 'normal'];
const HELPDESKS = ['Registrar', 'Accounts', 'Library'];

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.pdf': 'application/pdf'
};

// ---------- tiny file "database" ----------

function readJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    return fallback;
  }
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

const campus = readJSON(path.join(DATA_DIR, 'campus.json'), null);
if (!campus) {
  console.error('Could not read data/campus.json - is the data folder missing?');
  process.exit(1);
}
let notices = readJSON(NOTICES_FILE, []);
let inquiries = readJSON(INQUIRIES_FILE, []);

// ---------- notice priority sorting ----------
// urgent first, then important, then normal. Newest first inside each group.
const RANK = { urgent: 0, high: 1, normal: 2 };

function sortedNotices(list) {
  return [...list].sort((a, b) => {
    const byRank = RANK[a.priority] - RANK[b.priority];
    if (byRank !== 0) return byRank;
    return new Date(b.date) - new Date(a.date);
  });
}

// ---------- canteen crowd gauge ----------
// There is no real sensor, so the crowd level is estimated from the time of day:
// small bump at breakfast, big bump at lunch, medium bump at evening snacks.

function canteenStatus(now = new Date()) {
  const hour = now.getHours() + now.getMinutes() / 60;
  const cfg = campus.canteen;
  const toHour = (s) => Number(s.split(':')[0]) + Number(s.split(':')[1]) / 60;

  const today = cfg.menu[now.getDay()];
  const isOpen = hour >= toHour(cfg.open) && hour < toHour(cfg.close);

  let percent = 0;
  let level = 'Closed';

  if (isOpen) {
    const bump = (centre, width, height) => height * Math.exp(-Math.pow(hour - centre, 2) / (2 * width * width));
    percent = 8 + bump(8.5, 0.6, 25) + bump(13.0, 0.75, 80) + bump(16.5, 0.7, 35);
    percent += Math.sin(now.getMinutes() * 1.7) * 4; // wobble so it does not look frozen
    if (now.getDay() === 0) percent *= 0.4; // quieter on Sundays
    percent = Math.max(5, Math.min(98, Math.round(percent)));
    level = percent < 35 ? 'Low' : percent < 65 ? 'Moderate' : 'High';
  }

  return {
    date: now.toISOString(),
    open: isOpen,
    hours: `${cfg.open} - ${cfg.close}`,
    crowdPercent: percent,
    crowdLevel: level,
    menu: today
  };
}

// ---------- live updates (Server-Sent Events) ----------
const streamClients = new Set();

function broadcast(event, payload) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of streamClients) res.write(msg);
}

setInterval(() => {
  for (const res of streamClients) res.write(': keep-alive\n\n');
}, 25000);

// ---------- helpers ----------

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-cache'
  });
  res.end(body);
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function readBody(req, limit = 50000) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request body too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch (err) {
        reject(new HttpError(400, 'Body must be valid JSON'));
      }
    });
    req.on('error', reject);
  });
}

function requireAdmin(req) {
  if (req.headers['x-admin-key'] !== ADMIN_KEY) {
    throw new HttpError(401, 'Wrong or missing admin key');
  }
}

const clean = (v) => String(v == null ? '' : v).trim();

// ---------- API routes ----------

async function handleApi(req, res, url) {
  const route = url.pathname.replace(/\/+$/, '');
  const method = req.method;

  // campus data: buildings, graph, departments, canteen config
  if (route === '/api/campus' && method === 'GET') {
    const { canteen, ...rest } = campus; // menu comes from /api/canteen
    return sendJSON(res, 200, rest);
  }

  if (route === '/api/buildings' && method === 'GET') {
    return sendJSON(res, 200, campus.buildings);
  }

  const bMatch = route.match(/^\/api\/buildings\/([\w-]+)$/);
  if (bMatch && method === 'GET') {
    const b = campus.buildings.find((x) => x.id === bMatch[1]);
    if (!b) throw new HttpError(404, 'Building not found');
    return sendJSON(res, 200, b);
  }

  if (route === '/api/departments' && method === 'GET') {
    return sendJSON(res, 200, campus.departments);
  }

  // notices
  if (route === '/api/notices' && method === 'GET') {
    const cat = url.searchParams.get('category');
    let list = notices;
    if (cat && cat !== 'All') list = list.filter((n) => n.category === cat);
    return sendJSON(res, 200, sortedNotices(list));
  }

  if (route === '/api/notices' && method === 'POST') {
    requireAdmin(req);
    const b = await readBody(req);
    const title = clean(b.title);
    const body = clean(b.body);
    const category = clean(b.category);
    const priority = clean(b.priority) || 'normal';
    const pdf = clean(b.pdf);

    if (title.length < 3 || title.length > 120) throw new HttpError(400, 'Title must be 3-120 characters');
    if (!CATEGORIES.includes(category)) throw new HttpError(400, 'Invalid category');
    if (!PRIORITIES.includes(priority)) throw new HttpError(400, 'Invalid priority');
    if (body.length > 600) throw new HttpError(400, 'Body is too long (max 600 characters)');
    if (pdf && !/^(\/files\/|https?:\/\/)/.test(pdf)) throw new HttpError(400, 'PDF link must start with /files/ or http');

    const notice = {
      id: 'n' + Date.now(),
      title,
      category,
      priority,
      date: new Date().toISOString(),
      body,
      pdf: pdf || null
    };
    notices.push(notice);
    writeJSON(NOTICES_FILE, notices);
    broadcast('notice', notice);
    return sendJSON(res, 201, notice);
  }

  const nMatch = route.match(/^\/api\/notices\/([\w-]+)$/);
  if (nMatch && method === 'DELETE') {
    requireAdmin(req);
    const before = notices.length;
    notices = notices.filter((n) => n.id !== nMatch[1]);
    if (notices.length === before) throw new HttpError(404, 'Notice not found');
    writeJSON(NOTICES_FILE, notices);
    broadcast('removed', { id: nMatch[1] });
    return sendJSON(res, 200, { ok: true });
  }

  // live stream
  if (route === '/api/stream' && method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive'
    });
    res.write('retry: 5000\n\n');
    streamClients.add(res);
    req.on('close', () => streamClients.delete(res));
    return;
  }

  // canteen
  if (route === '/api/canteen' && method === 'GET') {
    return sendJSON(res, 200, canteenStatus());
  }

  // helpdesk inquiries
  if (route === '/api/inquiries' && method === 'POST') {
    const b = await readBody(req);
    const entry = {
      name: clean(b.name),
      rollNo: clean(b.rollNo),
      email: clean(b.email),
      department: clean(b.department),
      subject: clean(b.subject),
      message: clean(b.message)
    };

    if (entry.name.length < 2 || entry.name.length > 60) throw new HttpError(400, 'Please enter your name');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(entry.email)) throw new HttpError(400, 'Please enter a valid email');
    if (!HELPDESKS.includes(entry.department)) throw new HttpError(400, 'Choose Registrar, Accounts or Library');
    if (entry.subject.length < 3 || entry.subject.length > 100) throw new HttpError(400, 'Subject must be 3-100 characters');
    if (entry.message.length < 10 || entry.message.length > 1000) throw new HttpError(400, 'Message must be 10-1000 characters');

    entry.ref = 'INQ-' + Date.now().toString(36).toUpperCase();
    entry.submittedAt = new Date().toISOString();
    entry.status = 'Received';

    inquiries.push(entry);
    writeJSON(INQUIRIES_FILE, inquiries);
    return sendJSON(res, 201, { ok: true, ref: entry.ref });
  }

  if (route === '/api/inquiries' && method === 'GET') {
    requireAdmin(req);
    return sendJSON(res, 200, inquiries);
  }

  throw new HttpError(404, 'No such API route');
}

// ---------- static files ----------

function serveStatic(req, res, pathname) {
  let rel;
  try {
    rel = decodeURIComponent(pathname);
  } catch (err) {
    res.writeHead(400);
    return res.end('Bad request');
  }

  let filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.stat(filePath, (err, stat) => {
    if (!err && stat.isDirectory()) filePath = path.join(filePath, 'index.html');

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('404 - page not found');
      }
      const type = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
      res.end(content);
    });
  });
}

// ---------- server ----------

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
    } else if (req.method === 'GET' || req.method === 'HEAD') {
      serveStatic(req, res, url.pathname);
    } else {
      throw new HttpError(405, 'Method not allowed');
    }
  } catch (err) {
    const status = err.status || 500;
    if (status === 500) console.error(err);
    if (!res.headersSent) sendJSON(res, status, { error: status === 500 ? 'Server error' : err.message });
  }
});

server.listen(PORT, () => {
  console.log('CampusCanvas is running');
  console.log(`  Open  : http://localhost:${PORT}`);
  console.log(`  Admin : publish key is "${ADMIN_KEY}" (change it with the ADMIN_KEY environment variable)`);
});
