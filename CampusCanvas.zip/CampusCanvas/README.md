# CampusCanvas - SmartCampus

A responsive smart-campus web app: an interactive campus map, a live notice board with an urgent alert banner, a searchable department/faculty directory, a student helpdesk form, a walking route helper, a canteen menu with crowd gauge, and offline support.

Built for the SmartCampus Sprint problem brief (FSD project).

---

## 1. What you need on your laptop

| Tool | Why | Where to get it |
|---|---|---|
| **Node.js (LTS, version 18 or newer)** | Runs the backend server. This is the only thing you must install. | https://nodejs.org (download the "LTS" button) |
| **Google Chrome or Edge** | To open and test the app (also good for DevTools). | already on most laptops |
| **VS Code** | To read and edit the code. | https://code.visualstudio.com |
| Git (optional) | Only if your faculty wants a GitHub link. | https://git-scm.com |

No `npm install` is needed. The project has **zero dependencies** - the server uses only Node's built-in modules.

Check Node is installed: open a terminal (Command Prompt / PowerShell on Windows, Terminal on Mac/Linux) and type:

```
node -v
```

It should print something like `v20.x.x`. If it says "not recognized", install Node.js and restart the terminal.

---

## 2. How to run

1. Unzip `CampusCanvas.zip`.
2. Open the unzipped `CampusCanvas` folder in VS Code (File -> Open Folder).
3. Open the terminal in VS Code (Terminal -> New Terminal) and run:

```
node server.js
```

(or `npm start`)

4. You will see:

```
CampusCanvas is running
  Open  : http://localhost:3000
```

5. Open **http://localhost:3000** in Chrome.

To stop the server press `Ctrl + C` in the terminal.

**Port already in use?** Run on another port:
- Windows PowerShell: `$env:PORT=4000; node server.js`
- Command Prompt: `set PORT=4000 && node server.js`
- Mac/Linux: `PORT=4000 node server.js`

**Admin key** for publishing notices is `campus@123`. Change it with the `ADMIN_KEY` environment variable the same way as PORT.

**Test the logic (optional):** `node test/logic.test.js` runs 13 quick checks on search, routing and sorting.

---

## 3. Demo script (follow this when presenting)

1. Open the app on a phone-sized window (Chrome DevTools -> Toggle device toolbar) - the layout switches to the mobile version with a bottom menu.
2. In the search box type **DSP Lab**. Click the result. The map zooms to **Engineering Block 3**, a pin drops on it, and the side panel opens on the **2nd Floor** with **Room 204** highlighted.
3. Notice the red **URGENT** banner scrolling under the header. Click it - it opens the **Notices** page.
4. Click the **Examinations** tab. Click **Bookmark** on "Mid-Semester Exam Timetable Revised", then **View PDF** to open the schedule. Open the **Saved** tab to see the bookmark (it survives a page refresh).
5. Go back to **Map**, open the **Route helper**, choose Main Gate -> Engineering Block 3, click **Get route**. The path is drawn on the map with step-by-step directions.
6. **Directory** tab: filter "priyanka" to see faculty designation, room, extension and email link. Click the room number to jump to it on the map.
7. **Helpdesk** tab: submit an inquiry; you get a reference number (saved in `data/inquiries.json`).
8. **Canteen** tab: today's menu and the crowd gauge.
9. Live notice demo: open the app in two browser windows. In one, Notices -> "Publish a notice (admin)", fill the form with key `campus@123`, publish. The other window shows it instantly with a pop-up, and if it is Urgent it joins the red banner.
10. Offline demo: while the page is open, in DevTools -> Network choose **Offline** and reload. The map, directory and notices still load from the saved copy.

---

## 4. Features (against the problem brief)

**Must-have**

| Requirement | Where it is |
|---|---|
| Interactive 2D campus map | SVG map, 14 clickable buildings, drag / scroll-zoom / pinch-zoom, filter chips |
| Building & facility directory | Click a building: floors, room numbers, opening hours (with Open/Closed now), contact. Also Directory -> Buildings |
| Real-time notice ticker | Notices page, 5 categories + Saved, updated live using Server-Sent Events |
| Urgent alert banner | Red scrolling marquee at the top, built from notices marked Urgent |
| Department search & faculty roster | Directory -> Departments (designation, room, extension, email link) |
| Student inquiry & helpdesk form | Helpdesk page to Registrar / Accounts / Library, with validation |

**Stretch (all three done)**

- Route helper (shortest path with turn-by-turn steps)
- Canteen daily menu and crowd gauge
- Offline mode (service worker + localStorage cache + queued helpdesk inquiries)

---

## 5. How it was built

### Architecture

```
Browser (HTML + CSS + JavaScript)  <--- JSON over HTTP --->  Node.js server  <--->  JSON files (data/)
         |                                                        |
   SVG map, search,                                    serves the website, REST API,
   routing, notice UI                                  live stream (SSE), validation
```

I chose plain HTML/CSS/JavaScript for the front-end and the built-in `http` module for the server so it runs on any laptop with one command and nothing to install. The brief lists React/Express as a *suggested* stack; the same ideas (components, REST API, JSON storage) are used here in a simpler form.

### Folder structure

```
CampusCanvas/
├── server.js                 Backend: static files + REST API + live stream
├── package.json              Project info and "npm start"
├── data/
│   ├── campus.json           14 buildings, floors/rooms, road graph, departments, faculty, canteen menu
│   ├── notices.json          12 sample notices (the "database" for notices)
│   └── inquiries.json        created automatically when someone submits the helpdesk form
├── public/                   Everything the browser loads
│   ├── index.html            Page structure (all 5 screens)
│   ├── style.css             Styling, mobile-first, responsive
│   ├── manifest.json         Makes it installable as a PWA
│   ├── sw.js                 Service worker for offline mode
│   ├── icon.svg              App icon
│   ├── files/                PDFs linked from notices
│   └── js/
│       ├── logic.js          Pure logic: search, shortest path, opening hours, notice sorting
│       └── app.js            Draws the map and every screen, handles clicks, calls the API
└── test/logic.test.js        Automated checks for logic.js
```

### Step-by-step (how it was developed)

1. **Data first.** Made `campus.json` with 14 buildings (position on a 1000x640 grid, floors, rooms, hours), the road network (9 junctions + 12 road segments), 5 departments with faculty, and a 7-day canteen menu. Made `notices.json` with 12 notices.
2. **Server.** `server.js` serves the `public` folder and exposes the API (table below). It validates every input, protects against path traversal, and keeps notices/inquiries in JSON files.
3. **Map.** `app.js` reads the buildings and draws SVG: roads, footpaths, coloured buildings. Pan/zoom works by changing the SVG `viewBox`. Clicking a building opens the detail panel (bottom sheet on phones, side panel on desktop).
4. **Search.** `logic.js` builds one index of buildings, rooms, departments and faculty. Every word typed must match, and results are ranked (exact name > starts with > contains). That is why "DSP Lab" lands on Room 204.
5. **Routing.** Every building is connected by a footpath to a road junction, making a weighted graph. **Dijkstra's algorithm** finds the shortest path; consecutive moves in the same compass direction are merged and left/right turns are worked out using a cross product of the direction vectors. Distance is converted to metres and walking time at 1.3 m/s.
6. **Notices.** Sorted by priority (urgent > important > normal) then newest first. New notices published through the API are pushed to every open browser with **Server-Sent Events**. Bookmarks are stored in the browser's `localStorage`.
7. **Offline.** `sw.js` caches the app files; `app.js` saves the last API responses in `localStorage` and falls back to them when the network fails. A helpdesk inquiry made offline is queued and sent automatically when the connection returns.
8. **Responsive design.** Mobile-first CSS: bottom navigation bar on phones, top menu on laptops; the map is a vector (SVG) so it stays sharp at any zoom and loads fast.

### API reference

| Method & URL | What it does |
|---|---|
| `GET /api/campus` | Buildings, road graph, departments |
| `GET /api/buildings` / `GET /api/buildings/:id` | Building directory lookups |
| `GET /api/departments` | Departments with faculty |
| `GET /api/notices?category=Sports` | Notices sorted by priority (category optional) |
| `POST /api/notices` | Publish a notice (needs header `x-admin-key`) |
| `DELETE /api/notices/:id` | Remove a notice (needs `x-admin-key`) |
| `GET /api/stream` | Live notice updates (Server-Sent Events) |
| `GET /api/canteen` | Today's menu and estimated crowd level |
| `POST /api/inquiries` | Submit a helpdesk inquiry, returns a reference number |
| `GET /api/inquiries` | List inquiries (needs `x-admin-key`) |

### Honest notes

- The canteen crowd level is **estimated from the time of day** (peaks at lunch) - there is no real sensor.
- Buildings, faculty and notices are **sample data** for a fictional campus, as the brief allows. Replace them by editing `data/campus.json` and `data/notices.json`.
- Notices are stored in `data/notices.json`. To reset after testing, restore that file from the zip.

---

## 6. Make it yours (do this before submitting)

- In `public/index.html` change "Demo Institute of Technology" to your college name; do the same in `data/campus.json` (`name`) (the map code reads names from the data, so nothing else needs changing).
- Put your group number and member names here at the top of this README.
- Edit a few buildings, faculty and notices to match your real college.
- Read through `server.js`, `logic.js` and `app.js` once - the comments explain the main parts. Be ready to explain the project in your viva.

### Likely viva questions

1. **Why SVG instead of Google Maps?** No API key, works offline, scales without losing quality, and lets us draw custom building-level layouts.
2. **How does the route finder work?** Graph of junctions and buildings, Dijkstra finds the shortest path, then steps are built from the directions between points.
3. **How do notices update live?** The browser opens an `EventSource` to `/api/stream`; when an admin publishes, the server writes an event to every connected browser.
4. **How does offline mode work?** A service worker caches the files; the app stores the last API data in `localStorage` and falls back to it when `fetch` fails.
5. **How are urgent notices handled?** They are sorted first and also shown in the pinned scrolling banner so they never get buried in the feed.
6. **How is the data protected?** Inputs are validated on the server, output is HTML-escaped on the client (prevents XSS), publishing needs an admin key, and file paths are checked to stop path traversal.

---

## 7. Submitting on LetzProject

1. Make sure the project folder is named `CampusCanvas` and **does not contain a `node_modules` folder** (there isn't one).
2. Right-click the folder -> **Send to -> Compressed (zipped) folder** (Windows) or **Compress** (Mac).
3. Log in to http://167.86.100.213/ with your group credentials -> menu (three lines) -> **SRS Projects** -> upload the ZIP.
4. Deadline: **20 November 2026**.

## Troubleshooting

| Problem | Fix |
|---|---|
| `'node' is not recognized` | Install Node.js LTS and reopen the terminal |
| `EADDRINUSE` / port in use | Run on another port (see section 2) |
| Page says "Could not load campus data" | The server is not running - start it with `node server.js` |
| Old version shows after editing | Hard refresh with `Ctrl + Shift + R` (the service worker may have cached files) |
