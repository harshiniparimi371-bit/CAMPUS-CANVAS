// Pure logic used by the app: search, shortest-path routing, opening hours, notice sorting.
// Kept separate from the DOM code so it can be tested with plain Node (see test/logic.test.js).

(function (root) {
  'use strict';

  const PX_TO_M = 1.1;   // one map unit is roughly 1.1 metres
  const WALK_SPEED = 1.3; // metres per second

  const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

  const TYPE_NAMES = {
    academic: 'Academic block', library: 'Library', hostel: 'Hostel', canteen: 'Canteen',
    sports: 'Sports facility', admin: 'Administration', auditorium: 'Auditorium',
    health: 'Health', gate: 'Entrance'
  };

  // ---------- search ----------

  function buildIndex(campus) {
    const items = [];

    campus.buildings.forEach((b) => {
      const kw = (b.keywords || []).join(' ');
      items.push({
        kind: 'building',
        label: b.name,
        sub: TYPE_NAMES[b.type] || 'Building',
        buildingId: b.id,
        hay: norm(`${b.name} ${b.short} ${kw} ${TYPE_NAMES[b.type] || ''}`)
      });

      b.floors.forEach((f, fi) => {
        f.rooms.forEach((r) => {
          items.push({
            kind: 'room',
            label: r.name,
            sub: `${b.name} · ${f.floor} · Room ${r.no}`,
            buildingId: b.id,
            floorIdx: fi,
            room: r.no,
            hay: norm(`${r.name} ${r.no} ${b.name} ${b.short} ${kw}`)
          });
        });
      });
    });

    campus.departments.forEach((d) => {
      const b = campus.buildings.find((x) => x.id === d.building);
      items.push({
        kind: 'dept',
        label: d.name,
        sub: `Department · ${b ? b.name : ''}`,
        deptId: d.id,
        hay: norm(`${d.name} ${d.short} ${d.id} ${d.hod}`)
      });
      d.faculty.forEach((f) => {
        items.push({
          kind: 'faculty',
          label: f.name,
          sub: `${f.designation} · ${d.short}`,
          deptId: d.id,
          buildingId: d.building,
          room: f.room,
          hay: norm(`${f.name} ${f.designation} ${d.name} ${d.short}`)
        });
      });
    });

    return items;
  }

  // every word typed must appear somewhere in the entry; better matches float to the top
  function search(index, query, limit) {
    const q = norm(query);
    if (!q) return [];
    const words = q.split(' ');
    const kindOrder = { building: 0, room: 1, dept: 2, faculty: 3 };
    const hits = [];

    index.forEach((item) => {
      if (!words.every((w) => item.hay.includes(w))) return;
      const label = norm(item.label);
      let score = 3;
      if (label === q) score = 0;
      else if (label.startsWith(q)) score = 1;
      else if (label.includes(q)) score = 2;
      hits.push({ item, score: score + kindOrder[item.kind] * 0.1 });
    });

    hits.sort((a, b) => a.score - b.score);
    return hits.slice(0, limit || 8).map((h) => h.item);
  }

  // ---------- routing ----------

  function buildGraph(campus) {
    const nodes = {};
    const link = (a, b) => {
      const d = Math.hypot(nodes[a].x - nodes[b].x, nodes[a].y - nodes[b].y);
      nodes[a].adj.push([b, d]);
      nodes[b].adj.push([a, d]);
    };

    campus.graph.nodes.forEach((n) => {
      nodes[n.id] = { id: n.id, name: n.name, x: n.x, y: n.y, adj: [] };
    });
    campus.graph.edges.forEach(([a, b]) => link(a, b));

    // each building hangs off its nearest junction by a footpath
    campus.buildings.forEach((b) => {
      nodes[b.id] = { id: b.id, name: b.name, x: b.x + b.w / 2, y: b.y + b.h / 2, adj: [], isBuilding: true };
      link(b.id, b.junction);
    });
    return nodes;
  }

  function dijkstra(nodes, startId, endId) {
    const dist = {};
    const prev = {};
    const todo = new Set(Object.keys(nodes));
    Object.keys(nodes).forEach((id) => { dist[id] = Infinity; });
    dist[startId] = 0;

    while (todo.size) {
      let current = null;
      todo.forEach((id) => {
        if (current === null || dist[id] < dist[current]) current = id;
      });
      if (current === null || dist[current] === Infinity) break;
      if (current === endId) break;
      todo.delete(current);

      nodes[current].adj.forEach(([next, w]) => {
        if (dist[current] + w < dist[next]) {
          dist[next] = dist[current] + w;
          prev[next] = current;
        }
      });
    }

    if (dist[endId] === Infinity) return null;
    const path = [];
    for (let at = endId; at; at = prev[at]) {
      path.unshift(at);
      if (at === startId) break;
    }
    return path;
  }

  const VEC = { east: [1, 0], west: [-1, 0], south: [0, 1], north: [0, -1] };

  function heading(dx, dy) {
    if (Math.abs(dx) >= Math.abs(dy)) return dx > 0 ? 'east' : 'west';
    return dy > 0 ? 'south' : 'north';
  }

  const round5 = (m) => Math.max(5, Math.round(m / 5) * 5);

  function findRoute(campus, fromId, toId) {
    if (!fromId || !toId || fromId === toId) return null;
    const nodes = buildGraph(campus);
    if (!nodes[fromId] || !nodes[toId]) return null;

    const ids = dijkstra(nodes, fromId, toId);
    if (!ids) return null;
    const path = ids.map((id) => nodes[id]);

    // merge consecutive pieces that head the same way into one step
    const legs = [];
    for (let i = 0; i < path.length - 1; i++) {
      const a = path[i];
      const b = path[i + 1];
      const dir = heading(b.x - a.x, b.y - a.y);
      const len = Math.hypot(b.x - a.x, b.y - a.y) * PX_TO_M;
      const last = legs[legs.length - 1];
      if (last && last.dir === dir) {
        last.len += len;
        last.to = b;
      } else {
        legs.push({ dir, len, to: b });
      }
    }

    const steps = [`Start at ${path[0].name}.`];
    let total = 0;
    legs.forEach((leg, i) => {
      const metres = round5(leg.len);
      total += metres;
      let verb;
      if (i === 0) {
        verb = `Head ${leg.dir}`;
      } else {
        const [ax, ay] = VEC[legs[i - 1].dir];
        const [bx, by] = VEC[leg.dir];
        const cross = ax * by - ay * bx; // screen coordinates: positive = right turn
        verb = cross > 0 ? `Turn right and walk ${leg.dir}` : cross < 0 ? `Turn left and walk ${leg.dir}` : `Turn back and walk ${leg.dir}`;
      }
      const isLast = i === legs.length - 1;
      steps.push(`${verb} for about ${metres} m ${isLast ? `to reach ${leg.to.name}, your destination.` : `until you reach ${leg.to.name}.`}`);
    });

    return {
      from: path[0],
      to: path[path.length - 1],
      distance: total,
      minutes: Math.max(1, Math.ceil(total / WALK_SPEED / 60)),
      points: path.map((p) => ({ x: p.x, y: p.y })),
      steps
    };
  }

  // ---------- small helpers ----------

  function isOpenNow(hours, now) {
    if (!hours) return null;
    now = now || new Date();
    const toMin = (s) => {
      const parts = s.split(':').map(Number);
      return parts[0] * 60 + parts[1];
    };
    const mins = now.getHours() * 60 + now.getMinutes();
    return hours.days.includes(now.getDay()) && mins >= toMin(hours.open) && mins < toMin(hours.close);
  }

  const RANK = { urgent: 0, high: 1, normal: 2 };

  function sortNotices(list) {
    return list.slice().sort((a, b) => {
      const r = RANK[a.priority] - RANK[b.priority];
      return r !== 0 ? r : new Date(b.date) - new Date(a.date);
    });
  }

  function formatWhen(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
  }

  const api = { buildIndex, search, findRoute, isOpenNow, sortNotices, formatWhen, TYPE_NAMES, norm };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CC = api;
})(this);
