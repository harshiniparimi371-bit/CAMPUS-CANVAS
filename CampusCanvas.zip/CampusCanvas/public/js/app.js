// CampusCanvas front-end. Talks to the Node API, draws the SVG map, renders every screen.

(function () {
  'use strict';

  // ---------- small helpers ----------

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  function loadLS(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveLS(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* private mode / storage full */ }
  }

  // fetch JSON; when the network fails fall back to the copy saved in localStorage
  async function getData(url, cacheKey) {
    try {
      const res = await fetch(url, { cache: 'no-cache' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      saveLS(cacheKey, data);
      return data;
    } catch (err) {
      const cached = loadLS(cacheKey, null);
      if (cached) return cached;
      throw err;
    }
  }

  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 3500);
  }

  // ---------- state ----------

  const NOTICE_TABS = ['All', 'Academics', 'Examinations', 'Placements', 'Events', 'Sports', 'Saved'];

  const MAP_GROUPS = [
    { id: 'all', label: 'All', types: null },
    { id: 'academic', label: 'Academic', types: ['academic'] },
    { id: 'library', label: 'Library', types: ['library'] },
    { id: 'hostel', label: 'Hostels', types: ['hostel'] },
    { id: 'food', label: 'Food', types: ['canteen'] },
    { id: 'sports', label: 'Sports', types: ['sports'] },
    { id: 'services', label: 'Services', types: ['admin', 'auditorium', 'health', 'gate'] }
  ];

  const state = {
    campus: null,
    index: [],
    notices: [],
    bookmarks: loadLS('cc_bookmarks', []),
    view: 'map',
    noticeTab: 'All',
    mapGroup: 'all',
    selected: null,
    floorIdx: 0,
    hiRoom: null,
    dirSeg: 'departments'
  };

  const building = (id) => state.campus.buildings.find((b) => b.id === id);

  // ---------- navigation ----------

  function switchView(name) {
    state.view = name;
    $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
    $$('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
    if (location.hash !== '#' + name) history.replaceState(null, '', '#' + name);
    window.scrollTo(0, 0);
    if (name === 'canteen') loadCanteen();
  }

  // =====================================================================
  //  MAP
  // =====================================================================

  const MAP_W = 1000;
  const MAP_H = 640;
  const mapEl = $('#map');
  let vb = { x: 0, y: 0, w: MAP_W, h: MAP_H };

  function applyViewBox() {
    vb.w = clamp(vb.w, 260, MAP_W);
    vb.h = (vb.w * MAP_H) / MAP_W;
    vb.x = clamp(vb.x, 0, MAP_W - vb.w);
    vb.y = clamp(vb.y, 0, MAP_H - vb.h);
    mapEl.setAttribute('viewBox', `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
  }

  function zoomAt(factor, clientX, clientY) {
    const r = mapEl.getBoundingClientRect();
    const fx = (clientX - r.left) / r.width;
    const fy = (clientY - r.top) / r.height;
    const px = vb.x + fx * vb.w;
    const py = vb.y + fy * vb.h;
    vb.w = clamp(vb.w * factor, 260, MAP_W);
    vb.h = (vb.w * MAP_H) / MAP_W;
    vb.x = px - fx * vb.w;
    vb.y = py - fy * vb.h;
    applyViewBox();
  }

  function zoomCentre(factor) {
    const r = mapEl.getBoundingClientRect();
    zoomAt(factor, r.left + r.width / 2, r.top + r.height / 2);
  }

  function focusOn(b) {
    const cx = b.x + b.w / 2;
    const cy = b.y + b.h / 2;
    vb.w = 560;
    vb.h = (vb.w * MAP_H) / MAP_W;
    vb.x = cx - vb.w / 2;
    vb.y = cy - vb.h / 2;
    applyViewBox();
  }

  // split a long name over two lines
  function splitLabel(text) {
    if (text.length <= 10 || !text.includes(' ')) return [text];
    const words = text.split(' ');
    let best = 1;
    let bestDiff = Infinity;
    for (let i = 1; i < words.length; i++) {
      const diff = Math.abs(words.slice(0, i).join(' ').length - words.slice(i).join(' ').length);
      if (diff < bestDiff) { bestDiff = diff; best = i; }
    }
    return [words.slice(0, best).join(' '), words.slice(best).join(' ')];
  }

  function drawMap() {
    const c = state.campus;
    const nodeById = {};
    c.graph.nodes.forEach((n) => { nodeById[n.id] = n; });

    let svg = `<rect class="grass" x="0" y="0" width="${MAP_W}" height="${MAP_H}"/>`;

    // decoration (parking, garden)
    (c.decor || []).forEach((d) => {
      svg += `<rect class="decor-${d.kind}" x="${d.x}" y="${d.y}" width="${d.w}" height="${d.h}" rx="8"/>`;
      svg += `<text class="decor-label" x="${d.x + d.w / 2}" y="${d.y + d.h / 2 + 4}">${esc(d.label)}</text>`;
    });

    // roads: wide pale casing first, then the lighter surface on top
    const roadLines = c.graph.edges.map(([a, b]) => {
      const A = nodeById[a];
      const B = nodeById[b];
      return `x1="${A.x}" y1="${A.y}" x2="${B.x}" y2="${B.y}"`;
    });
    roadLines.forEach((l) => { svg += `<line class="road-casing" ${l}/>`; });
    roadLines.forEach((l) => { svg += `<line class="road" ${l}/>`; });

    // footpaths from each building to its junction
    c.buildings.forEach((b) => {
      const j = nodeById[b.junction];
      svg += `<line class="footpath" x1="${b.x + b.w / 2}" y1="${b.y + b.h / 2}" x2="${j.x}" y2="${j.y}"/>`;
    });

    // buildings
    c.buildings.forEach((b) => {
      const cx = b.x + b.w / 2;
      const cy = b.y + b.h / 2;
      const lines = splitLabel(b.short);
      const textY = cy - ((lines.length - 1) * 7) + 4;
      const tspans = lines.map((ln, i) => `<tspan x="${cx}" dy="${i === 0 ? 0 : 14}">${esc(ln)}</tspan>`).join('');

      svg += `<g class="bld t-${b.type}" data-id="${b.id}" data-type="${b.type}" tabindex="0" role="button" aria-label="${esc(b.name)}">`;
      svg += `<rect class="body" x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="7"/>`;
      if (b.id === 'sports') {
        svg += `<ellipse class="track" cx="${cx}" cy="${cy}" rx="${b.w / 2 - 12}" ry="${b.h / 2 - 12}"/>`;
      }
      svg += `<text x="${cx}" y="${textY}">${tspans}</text></g>`;
    });

    // layers for route and selected pin
    svg += '<g id="route-layer"></g><g id="marker-layer"></g>';

    // compass
    svg += '<g class="compass" transform="translate(955 45)"><path d="M0 -22 L7 4 L0 0 L-7 4 Z"/><text y="22">N</text></g>';

    mapEl.innerHTML = svg;
    applyViewBox();
  }

  // pan / pinch / wheel
  function bindMapGestures() {
    const pointers = new Map();
    let moved = false;
    let start = null;

    mapEl.addEventListener('pointerdown', (e) => {
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      start = { x: e.clientX, y: e.clientY };
      moved = false;
    });

    window.addEventListener('pointermove', (e) => {
      if (!pointers.has(e.pointerId)) return;
      const prev = pointers.get(e.pointerId);
      const cur = { x: e.clientX, y: e.clientY };

      if (pointers.size === 1) {
        const r = mapEl.getBoundingClientRect();
        const k = vb.w / r.width;
        vb.x -= (cur.x - prev.x) * k;
        vb.y -= (cur.y - prev.y) * k;
        applyViewBox();
        if (Math.hypot(cur.x - start.x, cur.y - start.y) > 6) moved = true;
      } else if (pointers.size === 2) {
        const other = Array.from(pointers.entries()).find(([id]) => id !== e.pointerId)[1];
        const before = Math.hypot(prev.x - other.x, prev.y - other.y);
        const after = Math.hypot(cur.x - other.x, cur.y - other.y);
        if (before > 0 && after > 0) zoomAt(before / after, (cur.x + other.x) / 2, (cur.y + other.y) / 2);
        moved = true;
      }
      pointers.set(e.pointerId, cur);
    });

    const release = (e) => pointers.delete(e.pointerId);
    window.addEventListener('pointerup', release);
    window.addEventListener('pointercancel', release);

    mapEl.addEventListener('wheel', (e) => {
      e.preventDefault();
      zoomAt(e.deltaY > 0 ? 1.15 : 0.87, e.clientX, e.clientY);
    }, { passive: false });

    mapEl.addEventListener('click', (e) => {
      if (moved) { moved = false; return; }
      const g = e.target.closest('.bld');
      if (g) selectBuilding(g.dataset.id);
    });

    mapEl.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const g = e.target.closest('.bld');
      if (g) { e.preventDefault(); selectBuilding(g.dataset.id); }
    });

    $('#zin').addEventListener('click', () => zoomCentre(0.75));
    $('#zout').addEventListener('click', () => zoomCentre(1.35));
    $('#zreset').addEventListener('click', () => { vb = { x: 0, y: 0, w: MAP_W, h: MAP_H }; applyViewBox(); });
  }

  // filter chips above the map
  function renderChips() {
    $('#chips').innerHTML = MAP_GROUPS.map((g) =>
      `<button class="chip ${state.mapGroup === g.id ? 'active' : ''}" data-group="${g.id}">${g.label}</button>`
    ).join('');
  }

  function applyMapFilter() {
    const group = MAP_GROUPS.find((g) => g.id === state.mapGroup);
    $$('.bld', mapEl).forEach((el) => {
      const hide = group.types && !group.types.includes(el.dataset.type);
      el.classList.toggle('dim', !!hide);
    });
  }

  function selectBuilding(id, opts) {
    opts = opts || {};
    const b = building(id);
    if (!b) return;

    state.selected = id;
    state.hiRoom = opts.room || null;
    state.floorIdx = 0;

    if (state.hiRoom) {
      const idx = b.floors.findIndex((f) => f.rooms.some((r) => r.no === state.hiRoom));
      if (idx >= 0) state.floorIdx = idx;
    } else if (typeof opts.floorIdx === 'number') {
      state.floorIdx = opts.floorIdx;
    }

    switchView('map');
    $$('.bld', mapEl).forEach((el) => el.classList.toggle('sel', el.dataset.id === id));

    const cx = b.x + b.w / 2;
    $('#marker-layer').innerHTML =
      `<g class="pin" transform="translate(${cx} ${b.y + 2})">` +
      '<circle class="pulse" cy="-14" r="6"/>' +
      '<path d="M0 0 c-9 -14 -14 -20 -14 -28 a14 14 0 1 1 28 0 c0 8 -5 14 -14 28z"/>' +
      '<circle cy="-28" r="5" fill="#fff"/></g>';

    renderDrawer();
    focusOn(b);
  }

  function closeDrawer() {
    state.selected = null;
    $('#drawer').classList.remove('open');
    $$('.bld', mapEl).forEach((el) => el.classList.remove('sel'));
    $('#marker-layer').innerHTML = '';
  }

  function renderDrawer() {
    const drawer = $('#drawer');
    const b = state.selected && building(state.selected);
    if (!b) { drawer.classList.remove('open'); return; }

    const open = CC.isOpenNow(b.hours);
    const floor = b.floors[state.floorIdx] || b.floors[0];
    const depts = state.campus.departments.filter((d) => d.building === b.id);

    drawer.innerHTML = `
      <div class="d-head">
        <div>
          <div class="d-type">${esc(CC.TYPE_NAMES[b.type] || '')}</div>
          <h3>${esc(b.name)}<span class="d-badge ${open ? 'open' : 'closed'}">${open ? 'Open now' : 'Closed now'}</span></h3>
        </div>
        <button class="d-close" data-act="close" aria-label="Close">&times;</button>
      </div>
      <p class="muted">${esc(b.about)}</p>
      <div class="d-info">
        <div><b>Hours:</b> ${esc(b.hours.text)}</div>
        <div><b>Contact:</b> ${esc(b.contact.name)} &middot; ext. ${esc(b.contact.ext)}</div>
      </div>
      <div class="d-actions">
        <button class="btn small" data-act="from">Directions from here</button>
        <button class="btn small ghost" data-act="to">Directions to here</button>
      </div>
      <div class="floor-tabs">
        ${b.floors.map((f, i) => `<button data-floor="${i}" class="${i === state.floorIdx ? 'active' : ''}">${esc(f.floor)}</button>`).join('')}
      </div>
      <ul class="rooms">
        ${floor.rooms.map((r) => `
          <li class="${r.no === state.hiRoom ? 'hit' : ''}">
            <span class="no">${esc(r.no)}</span><span>${esc(r.name)}</span>
          </li>`).join('')}
      </ul>
      ${depts.map((d) => `<a href="#directory" class="dept-link" data-dept="${esc(d.id)}">Faculty list: ${esc(d.name)} &rarr;</a>`).join('<br>')}
    `;
    drawer.classList.add('open');
  }

  // =====================================================================
  //  ROUTE HELPER
  // =====================================================================

  function fillRouteSelects() {
    const opts = state.campus.buildings
      .slice()
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((b) => `<option value="${b.id}">${esc(b.name)}</option>`)
      .join('');
    $('#route-from').innerHTML = opts;
    $('#route-to').innerHTML = opts;
    $('#route-from').value = 'gate';
    $('#route-to').value = 'eng3';
  }

  function showRoute() {
    const from = $('#route-from').value;
    const to = $('#route-to').value;
    const out = $('#route-out');
    const layer = $('#route-layer');

    if (from === to) {
      out.innerHTML = '<p class="muted">Pick two different buildings.</p>';
      layer.innerHTML = '';
      return;
    }

    const route = CC.findRoute(state.campus, from, to);
    if (!route) {
      out.innerHTML = '<p class="muted">No walking route found.</p>';
      layer.innerHTML = '';
      return;
    }

    out.innerHTML = `
      <div class="route-summary">${route.distance} m &middot; about ${route.minutes} min walk</div>
      <ol class="steps">${route.steps.slice(1).map((s) => `<li>${esc(s)}</li>`).join('')}</ol>`;

    const pts = route.points.map((p) => `${p.x},${p.y}`).join(' ');
    const first = route.points[0];
    const last = route.points[route.points.length - 1];
    layer.innerHTML =
      `<polyline class="route-line" points="${pts}"/>` +
      `<circle class="route-end" cx="${first.x}" cy="${first.y}" r="8"/>` +
      `<circle class="route-end dest" cx="${last.x}" cy="${last.y}" r="8"/>`;

    // zoom out so the whole route is visible
    vb = { x: 0, y: 0, w: MAP_W, h: MAP_H };
    applyViewBox();
  }

  function routeFromDrawer(which) {
    const id = state.selected;
    if (!id) return;
    if (which === 'from') {
      $('#route-from').value = id;
      if ($('#route-to').value === id) $('#route-to').value = id === 'gate' ? 'library' : 'gate';
    } else {
      $('#route-to').value = id;
      if ($('#route-from').value === id) $('#route-from').value = id === 'gate' ? 'library' : 'gate';
    }
    $('#route-card').open = true;
    closeDrawer();
    showRoute();
    $('#route-card').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  // =====================================================================
  //  SEARCH
  // =====================================================================

  const KIND_LABEL = { building: 'Building', room: 'Room', dept: 'Dept', faculty: 'Faculty' };
  let searchHits = [];
  let searchPos = -1;

  function renderSearch() {
    const box = $('#search-results');
    const q = $('#search').value;
    if (!q.trim()) { box.hidden = true; return; }

    searchHits = CC.search(state.index, q, 8);
    searchPos = searchHits.length ? 0 : -1;

    if (!searchHits.length) {
      box.innerHTML = '<li class="none">Nothing found. Try a lab name, room number or faculty name.</li>';
    } else {
      box.innerHTML = searchHits.map((h, i) => `
        <li data-i="${i}" class="${i === searchPos ? 'hl' : ''}">
          <span class="r-kind">${KIND_LABEL[h.kind]}</span>
          <span class="r-label">${esc(h.label)}</span>
          <span class="r-sub">${esc(h.sub)}</span>
        </li>`).join('');
    }
    box.hidden = false;
  }

  function pickResult(item) {
    $('#search-results').hidden = true;
    if (!item) return;
    $('#search').blur();

    if (item.kind === 'building') {
      selectBuilding(item.buildingId);
    } else if (item.kind === 'room') {
      selectBuilding(item.buildingId, { room: item.room, floorIdx: item.floorIdx });
    } else if (item.kind === 'faculty') {
      selectBuilding(item.buildingId, { room: item.room });
    } else if (item.kind === 'dept') {
      const d = state.campus.departments.find((x) => x.id === item.deptId);
      state.dirSeg = 'departments';
      $('#dir-q').value = d ? d.name : '';
      renderDirectory();
      switchView('directory');
    }
  }

  function bindSearch() {
    const input = $('#search');
    const box = $('#search-results');

    input.addEventListener('input', renderSearch);
    input.addEventListener('focus', renderSearch);

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { box.hidden = true; return; }
      if (box.hidden || !searchHits.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        searchPos = (searchPos + (e.key === 'ArrowDown' ? 1 : -1) + searchHits.length) % searchHits.length;
        $$('li', box).forEach((li, i) => li.classList.toggle('hl', i === searchPos));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        pickResult(searchHits[searchPos]);
      }
    });

    // mousedown (not click) so it fires before the input loses focus
    box.addEventListener('mousedown', (e) => {
      const li = e.target.closest('li[data-i]');
      if (li) { e.preventDefault(); pickResult(searchHits[Number(li.dataset.i)]); }
    });
    box.addEventListener('touchend', (e) => {
      const li = e.target.closest('li[data-i]');
      if (li) { e.preventDefault(); pickResult(searchHits[Number(li.dataset.i)]); }
    });

    input.addEventListener('blur', () => setTimeout(() => { box.hidden = true; }, 150));
  }

  // =====================================================================
  //  NOTICES
  // =====================================================================

  function renderBanner() {
    const urgent = CC.sortNotices(state.notices).filter((n) => n.priority === 'urgent');
    const banner = $('#alert-banner');
    if (!urgent.length) { banner.hidden = true; return; }

    const text = urgent.map((n) => `<span>${esc(n.title)}</span>`).join('');
    const track = $('#marquee-track');
    track.innerHTML = text;
    const chars = urgent.reduce((sum, n) => sum + n.title.length, 0);
    track.style.animationDuration = Math.max(18, chars * 0.35) + 's';
    banner.hidden = false;
  }

  function noticeHTML(n) {
    const saved = state.bookmarks.includes(n.id);
    const tag = n.priority === 'urgent' ? '<span class="tag tag-urgent">Urgent</span>'
      : n.priority === 'high' ? '<span class="tag tag-high">Important</span>' : '';
    return `
      <article class="notice p-${esc(n.priority)}" data-id="${esc(n.id)}">
        <div class="notice-top">${tag}<span class="cat">${esc(n.category)}</span><time>${esc(CC.formatWhen(n.date))}</time></div>
        <h3>${esc(n.title)}</h3>
        <p>${esc(n.body)}</p>
        <div class="notice-actions">
          ${n.pdf ? `<a class="btn small ghost" href="${esc(n.pdf)}" target="_blank" rel="noopener">View PDF</a>` : ''}
          <button class="btn small ${saved ? 'saved' : 'ghost'}" data-act="bookmark">${saved ? 'Bookmarked' : 'Bookmark'}</button>
        </div>
      </article>`;
  }

  function renderNotices() {
    const all = CC.sortNotices(state.notices);

    // tabs with counts
    $('#notice-tabs').innerHTML = NOTICE_TABS.map((t) => {
      let count;
      if (t === 'All') count = all.length;
      else if (t === 'Saved') count = all.filter((n) => state.bookmarks.includes(n.id)).length;
      else count = all.filter((n) => n.category === t).length;
      return `<button data-tab="${t}" class="${state.noticeTab === t ? 'active' : ''}">${t}<span class="count">${count}</span></button>`;
    }).join('');

    let list = all;
    if (state.noticeTab === 'Saved') list = all.filter((n) => state.bookmarks.includes(n.id));
    else if (state.noticeTab !== 'All') list = all.filter((n) => n.category === state.noticeTab);

    $('#notice-list').innerHTML = list.length
      ? list.map(noticeHTML).join('')
      : `<div class="empty">${state.noticeTab === 'Saved' ? 'You have not bookmarked any notices yet.' : 'No notices in this category.'}</div>`;
  }

  function saveNotices() { saveLS('cc_notices', state.notices); }

  function toggleBookmark(id) {
    const i = state.bookmarks.indexOf(id);
    if (i >= 0) state.bookmarks.splice(i, 1);
    else state.bookmarks.push(id);
    saveLS('cc_bookmarks', state.bookmarks);
    renderNotices();
  }

  // live updates from the server
  function connectStream() {
    if (!window.EventSource) return;
    const es = new EventSource('api/stream');

    es.addEventListener('notice', (e) => {
      const n = JSON.parse(e.data);
      if (state.notices.some((x) => x.id === n.id)) return;
      state.notices.push(n);
      saveNotices();
      renderNotices();
      renderBanner();
      toast((n.priority === 'urgent' ? 'URGENT: ' : 'New notice: ') + n.title);
    });

    es.addEventListener('removed', (e) => {
      const { id } = JSON.parse(e.data);
      state.notices = state.notices.filter((n) => n.id !== id);
      saveNotices();
      renderNotices();
      renderBanner();
    });
    // EventSource reconnects by itself when the connection drops
  }

  async function refreshNotices() {
    try {
      state.notices = await getData('api/notices', 'cc_notices');
      renderNotices();
      renderBanner();
    } catch (e) { /* keep what we have */ }
  }

  function bindPublish() {
    $('#publish-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const form = e.target;
      const data = Object.fromEntries(new FormData(form));
      const key = data.key;
      delete data.key;
      try {
        const res = await fetch('api/notices', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-admin-key': key },
          body: JSON.stringify(data)
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Could not publish');
        form.reset();
        toast('Notice published');
        // the stream also delivers it, but add it right away in case the stream is down
        if (!state.notices.some((n) => n.id === json.id)) {
          state.notices.push(json);
          saveNotices();
          renderNotices();
          renderBanner();
        }
      } catch (err) {
        toast(err.message === 'Failed to fetch' ? 'You are offline' : err.message);
      }
    });
  }

  // =====================================================================
  //  DIRECTORY
  // =====================================================================

  function renderDirectory() {
    const q = CC.norm($('#dir-q').value);
    const box = $('#dir-list');
    $$('#dir-seg button').forEach((b) => b.classList.toggle('active', b.dataset.seg === state.dirSeg));

    if (state.dirSeg === 'buildings') {
      const list = state.campus.buildings.filter((b) =>
        !q || CC.norm(`${b.name} ${b.short} ${(b.keywords || []).join(' ')} ${CC.TYPE_NAMES[b.type]}`).includes(q));
      box.innerHTML = list.map((b) => `
        <div class="card b-item">
          <div>
            <b>${esc(b.name)}</b>
            <small>${esc(CC.TYPE_NAMES[b.type])} &middot; ${esc(b.hours.text)}</small>
            <small>${esc(b.contact.name)} &middot; ext. ${esc(b.contact.ext)}</small>
          </div>
          <button class="btn small" data-b="${esc(b.id)}">Show on map</button>
        </div>`).join('') || '<div class="empty">No buildings match.</div>';
      return;
    }

    const html = state.campus.departments.map((d) => {
      const b = building(d.building);
      const deptMatch = !q || CC.norm(`${d.name} ${d.short} ${d.hod}`).includes(q);
      const rows = d.faculty.filter((f) =>
        deptMatch || CC.norm(`${f.name} ${f.designation} ${f.room}`).includes(q));
      if (!rows.length) return '';

      return `
        <div class="card dept">
          <div class="dept-head">
            <h3>${esc(d.name)}</h3>
            <small>HoD: ${esc(d.hod)} &middot; ${esc(b ? b.name : '')}</small>
          </div>
          <table class="fac-table">
            <thead><tr><th>Faculty</th><th>Room</th><th>Ext.</th></tr></thead>
            <tbody>
              ${rows.map((f) => `
                <tr>
                  <td><b>${esc(f.name)}</b><span class="desig">${esc(f.designation)}</span>
                      <a href="mailto:${esc(f.email)}">${esc(f.email)}</a></td>
                  <td><button class="linkbtn" data-b="${esc(d.building)}" data-room="${esc(f.room)}">${esc(f.room)}</button></td>
                  <td>${esc(f.ext)}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`;
    }).join('');

    box.innerHTML = html || '<div class="empty">No faculty or departments match.</div>';
  }

  // =====================================================================
  //  HELPDESK
  // =====================================================================

  function showInquiryMsg(kind, text) {
    const el = $('#inquiry-msg');
    el.className = 'form-msg ' + kind;
    el.textContent = text;
    el.hidden = false;
  }

  async function sendInquiry(data) {
    const res = await fetch('api/inquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Could not submit');
    return json;
  }

  async function flushPending() {
    const pending = loadLS('cc_pending_inquiries', []);
    if (!pending.length || !navigator.onLine) return;
    const failed = [];
    for (const item of pending) {
      try { await sendInquiry(item); } catch (err) { failed.push(item); }
    }
    saveLS('cc_pending_inquiries', failed);
    if (failed.length < pending.length) toast('Your saved inquiry has been sent');
  }

  function bindInquiryForm() {
    $('#inquiry-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const form = e.target;
      const data = Object.fromEntries(new FormData(form));
      const btn = form.querySelector('button[type=submit]');
      btn.disabled = true;

      try {
        const json = await sendInquiry(data);
        showInquiryMsg('ok', `Submitted. Your reference number is ${json.ref}. Keep it for follow-ups.`);
        form.reset();
      } catch (err) {
        if (err instanceof TypeError || !navigator.onLine) {
          // network problem: keep it and send when we are back online
          const pending = loadLS('cc_pending_inquiries', []);
          pending.push(data);
          saveLS('cc_pending_inquiries', pending);
          showInquiryMsg('warn', 'You are offline. Your inquiry is saved on this device and will be sent automatically when you are back online.');
          form.reset();
        } else {
          showInquiryMsg('err', err.message);
        }
      } finally {
        btn.disabled = false;
      }
    });
  }

  // =====================================================================
  //  CANTEEN
  // =====================================================================

  async function loadCanteen() {
    const box = $('#canteen-box');
    try {
      const c = await getData('api/canteen', 'cc_canteen');
      const cls = c.crowdLevel === 'Low' ? 'low' : c.crowdLevel === 'Moderate' ? 'mod' : 'high';
      box.innerHTML = `
        <h3>Today's menu &middot; ${esc(c.menu.day)}</h3>
        <div class="menu-row"><small>Breakfast</small>${esc(c.menu.breakfast)}</div>
        <div class="menu-row"><small>Lunch special</small>${esc(c.menu.lunch)}</div>
        <div class="menu-row"><small>Evening snacks</small>${esc(c.menu.snacks)}</div>

        <h3 style="margin-top:18px">Crowd right now</h3>
        <div class="gauge-wrap">
          <div class="gauge"><div class="gauge-fill ${cls}" style="width:${c.crowdPercent}%"></div></div>
          <div class="gauge-info">
            <span><b>${esc(c.crowdLevel)}</b>${c.open ? ` (${c.crowdPercent}% full)` : ''}</span>
            <span class="muted">Open ${esc(c.hours)}</span>
          </div>
        </div>
        <p class="muted">The crowd level is an estimate based on the time of day.</p>`;
    } catch (err) {
      box.innerHTML = '<p class="muted">Could not load the canteen details. Check your connection.</p>';
    }
  }

  // =====================================================================
  //  START UP
  // =====================================================================

  function updateOnlineState() {
    $('#offline-bar').hidden = navigator.onLine;
  }

  function bindEvents() {
    $('#tabs').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-view]');
      if (b) switchView(b.dataset.view);
    });

    $('#chips').addEventListener('click', (e) => {
      const b = e.target.closest('.chip');
      if (!b) return;
      state.mapGroup = b.dataset.group;
      renderChips();
      applyMapFilter();
    });

    $('#drawer').addEventListener('click', (e) => {
      const floorBtn = e.target.closest('[data-floor]');
      if (floorBtn) {
        state.floorIdx = Number(floorBtn.dataset.floor);
        renderDrawer();
        return;
      }
      const deptLink = e.target.closest('[data-dept]');
      if (deptLink) {
        e.preventDefault();
        const d = state.campus.departments.find((x) => x.id === deptLink.dataset.dept);
        state.dirSeg = 'departments';
        $('#dir-q').value = d ? d.name : '';
        renderDirectory();
        switchView('directory');
        return;
      }
      const act = e.target.closest('[data-act]');
      if (!act) return;
      if (act.dataset.act === 'close') closeDrawer();
      else if (act.dataset.act === 'from') routeFromDrawer('from');
      else if (act.dataset.act === 'to') routeFromDrawer('to');
    });

    $('#route-go').addEventListener('click', showRoute);
    $('#route-swap').addEventListener('click', () => {
      const a = $('#route-from').value;
      $('#route-from').value = $('#route-to').value;
      $('#route-to').value = a;
      showRoute();
    });

    $('#alert-banner').addEventListener('click', () => {
      state.noticeTab = 'All';
      renderNotices();
      switchView('notices');
    });

    $('#notice-tabs').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-tab]');
      if (!b) return;
      state.noticeTab = b.dataset.tab;
      renderNotices();
    });

    $('#notice-list').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act=bookmark]');
      if (btn) toggleBookmark(btn.closest('.notice').dataset.id);
    });

    $('#dir-seg').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-seg]');
      if (!b) return;
      state.dirSeg = b.dataset.seg;
      renderDirectory();
    });
    $('#dir-q').addEventListener('input', renderDirectory);

    $('#dir-list').addEventListener('click', (e) => {
      const b = e.target.closest('[data-b]');
      if (!b) return;
      selectBuilding(b.dataset.b, b.dataset.room ? { room: b.dataset.room } : {});
    });

    window.addEventListener('online', () => { updateOnlineState(); flushPending(); refreshNotices(); });
    window.addEventListener('offline', updateOnlineState);

    window.addEventListener('hashchange', () => {
      const v = location.hash.replace('#', '');
      if (['map', 'notices', 'directory', 'helpdesk', 'canteen'].includes(v) && v !== state.view) switchView(v);
    });

    bindMapGestures();
    bindSearch();
    bindPublish();
    bindInquiryForm();
  }

  async function init() {
    updateOnlineState();

    try {
      state.campus = await getData('api/campus', 'cc_campus');
    } catch (err) {
      $('#view-map').innerHTML = '<div class="page"><p>Could not load campus data. Make sure the server is running (node server.js) and refresh.</p></div>';
      return;
    }

    try {
      state.notices = await getData('api/notices', 'cc_notices');
    } catch (err) {
      state.notices = [];
    }

    state.index = CC.buildIndex(state.campus);

    drawMap();
    renderChips();
    fillRouteSelects();
    renderNotices();
    renderBanner();
    renderDirectory();
    bindEvents();

    const startView = location.hash.replace('#', '');
    if (['notices', 'directory', 'helpdesk', 'canteen'].includes(startView)) switchView(startView);

    connectStream();
    flushPending();
    setInterval(() => { if (state.view === 'canteen') loadCanteen(); }, 60000);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => { /* not fatal */ });
    }
  }

  init();
})();
