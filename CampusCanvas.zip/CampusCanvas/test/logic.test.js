// Quick self-check for the search + routing logic. Run with:  node test/logic.test.js
const fs = require('fs');
const path = require('path');
const CC = require('../public/js/logic.js');

const campus = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'campus.json'), 'utf8'));
const index = CC.buildIndex(campus);

let passed = 0;
function check(name, cond) {
  if (!cond) { console.error('FAIL  ' + name); process.exitCode = 1; }
  else { console.log('ok    ' + name); passed++; }
}

// the demo from the problem brief
const dsp = CC.search(index, 'DSP Lab', 5)[0];
check('"DSP Lab" finds the DSP lab room', dsp && dsp.kind === 'room' && dsp.room === '204');
check('...inside Engineering Block 3, 2nd floor', dsp && dsp.buildingId === 'eng3' && dsp.floorIdx === 2);

check('search "library" returns the library first', CC.search(index, 'library', 3)[0].buildingId === 'library');
check('search finds faculty by name', CC.search(index, 'priyanka', 3)[0].kind === 'faculty');
check('empty search returns nothing', CC.search(index, '   ').length === 0);

// every building must be reachable from the main gate
const unreachable = campus.buildings.filter((b) => b.id !== 'gate' && !CC.findRoute(campus, 'gate', b.id));
check('all 13 other buildings reachable from the gate', unreachable.length === 0);

const r = CC.findRoute(campus, 'gate', 'eng3');
check('gate -> Engg Block 3 has a route with steps', r && r.steps.length >= 3 && r.distance > 0);
console.log('\n  Sample route: ' + r.distance + ' m, ~' + r.minutes + ' min');
r.steps.forEach((s) => console.log('   - ' + s));
console.log('');

check('same start and end gives no route', CC.findRoute(campus, 'cs', 'cs') === null);

// distance must be the same in both directions
const ab = CC.findRoute(campus, 'library', 'hostel2');
const ba = CC.findRoute(campus, 'hostel2', 'library');
check('route length is symmetric', ab.distance === ba.distance);

// priority sorting
const sorted = CC.sortNotices([
  { id: 'a', priority: 'normal', date: '2026-11-18' },
  { id: 'b', priority: 'urgent', date: '2026-11-01' },
  { id: 'c', priority: 'high', date: '2026-11-10' },
  { id: 'd', priority: 'urgent', date: '2026-11-05' }
]).map((n) => n.id).join('');
check('notices sort urgent > high > normal, newest first', sorted === 'dbca');

// opening hours (Wednesday 11:00 vs 22:00)
const lib = campus.buildings.find((b) => b.id === 'library');
check('library open Wed 11:00', CC.isOpenNow(lib.hours, new Date(2026, 10, 18, 11, 0)) === true);
check('library closed Wed 22:00', CC.isOpenNow(lib.hours, new Date(2026, 10, 18, 22, 0)) === false);
check('library closed on Sunday', CC.isOpenNow(lib.hours, new Date(2026, 10, 22, 11, 0)) === false);

console.log(`\n${passed} checks passed`);
